> This issue proposes a [bug, feature] which...

### Background & Context

Please provide some more detailed information about the general background and context of this issue and delete non applicable sections below.

### Bug

#### Input

Some HTML which is thrown at DOMPurify.

#### Given output

The output given by DOMPurify.

#### Expected output

The expected output.

### Feature

Briefly outline the proposed feature, its value and a potentially proposed implementation from a high level.
